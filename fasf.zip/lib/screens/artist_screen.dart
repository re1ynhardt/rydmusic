import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/artist_page.dart';
import '../models/track.dart';
import '../providers/language_provider.dart';
import '../providers/player_provider.dart';
import '../services/music_source.dart';
import '../theme/app_theme.dart';
import '../widgets/track_tile.dart';

/// Страница исполнителя: альбомы (треки раскрываются по тапу) и все треки
/// списком. Данные — только из источника, откуда играет текущий трек
/// (YouTube → только YouTube, SoundCloud → только SoundCloud).
/// Открывается свайпом влево на экране "Сейчас играет".
class ArtistScreen extends StatefulWidget {
  const ArtistScreen({super.key, required this.track, required this.source});

  final Track track;
  final MusicSource source;

  @override
  State<ArtistScreen> createState() => _ArtistScreenState();
}

class _ArtistScreenState extends State<ArtistScreen> {
  late Future<ArtistPage?> _future;
  bool _albumsView = true;

  // Треки альбомов грузятся один раз, при первом раскрытии.
  final Map<String, Future<List<Track>>> _albumTracks = {};

  @override
  void initState() {
    super.initState();
    _future = widget.source.loadArtist(widget.track);
  }

  void _retry() => setState(() {
        _albumTracks.clear();
        _future = widget.source.loadArtist(widget.track);
      });

  /// Окно очереди вокруг нажатого трека: PlayerProvider резолвит очередь
  /// целиком, а у исполнителя может быть под 200 треков — столько
  /// резолвов (особенно YouTube) ни к чему.
  void _play(Track t, List<Track> list) {
    final i = list.indexWhere((e) => e.id == t.id);
    final from = (i - 10).clamp(0, list.length);
    final to = (i + 30).clamp(0, list.length);
    context.read<PlayerProvider>().playTrack(t, queue: list.sublist(from, to));
  }

  Widget _cover(String url, double size, {bool round = false}) {
    final child = url.isEmpty
        ? Container(
            width: size,
            height: size,
            color: AppColors.surfaceElevated,
            child: Icon(round ? Icons.person_rounded : Icons.album_rounded,
                color: AppColors.textSecondary),
          )
        : CachedNetworkImage(
            imageUrl: url,
            width: size,
            height: size,
            fit: BoxFit.cover,
            memCacheWidth: (size * 3).round(),
            errorWidget: (_, __, ___) =>
                Container(width: size, height: size, color: AppColors.surfaceElevated),
          );
    return round
        ? ClipOval(child: child)
        : ClipRRect(borderRadius: BorderRadius.circular(8), child: child);
  }

  Widget _chip(String label, bool albums) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: _albumsView == albums,
          showCheckmark: false,
          side: BorderSide.none,
          backgroundColor: AppColors.surfaceElevated,
          selectedColor: AppColors.accentEnd.withOpacity(0.35),
          labelStyle: TextStyle(color: AppColors.textPrimary),
          onSelected: (_) => setState(() => _albumsView = albums),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    final activeId =
        context.select<PlayerProvider, String?>((p) => p.currentTrack?.id);

    Widget tile(Track t, List<Track> list) => TrackTile(
          track: t,
          isActive: t.id == activeId,
          onTap: () => _play(t, list),
        );

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: FutureBuilder<ArtistPage?>(
          future: _future,
          builder: (context, snap) {
            final page = snap.data;
            final loading = snap.connectionState != ConnectionState.done;
            final failed = !loading && (snap.hasError || page == null);

            Widget body;
            if (loading) {
              body = const Center(child: CircularProgressIndicator());
            } else if (failed) {
              body = Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(l10n.artistLoadFailed,
                        style: TextStyle(color: AppColors.textSecondary)),
                    TextButton(onPressed: _retry, child: Text(l10n.retry)),
                  ],
                ),
              );
            } else if (_albumsView) {
              body = page!.albums.isEmpty
                  ? Center(
                      child: Text(l10n.artistNothingFound,
                          style: TextStyle(color: AppColors.textSecondary)))
                  : ListView.builder(
                      itemCount: page.albums.length,
                      itemBuilder: (_, i) => _albumTile(page.albums[i], tile),
                    );
            } else {
              body = page!.tracks.isEmpty
                  ? Center(
                      child: Text(l10n.artistNothingFound,
                          style: TextStyle(color: AppColors.textSecondary)))
                  : ListView.builder(
                      itemCount: page.tracks.length,
                      itemBuilder: (_, i) => tile(page.tracks[i], page.tracks),
                    );
            }

            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(4, 4, 16, 8),
                  child: Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back_ios_new_rounded,
                            color: AppColors.textPrimary),
                        onPressed: () => Navigator.of(context).maybePop(),
                      ),
                      _cover(page?.artworkUrl ?? '', 44, round: true),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          page?.name ?? widget.track.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary),
                        ),
                      ),
                    ],
                  ),
                ),
                if (page != null)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: Row(children: [
                      _chip(l10n.artistAlbums, true),
                      _chip(l10n.artistTracks, false),
                    ]),
                  ),
                Expanded(child: body),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _albumTile(
      ArtistAlbum album, Widget Function(Track, List<Track>) tile) {
    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        // Ключ по id — состояние раскрытия не "прилипает" к другой строке.
        key: PageStorageKey<String>('album_${album.id}'),
        iconColor: AppColors.textSecondary,
        collapsedIconColor: AppColors.textSecondary,
        leading: _cover(album.artworkUrl, 52),
        title: Text(album.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
                color: AppColors.textPrimary, fontWeight: FontWeight.w700)),
        subtitle: album.subtitle.isEmpty
            ? null
            : Text(album.subtitle,
                style: TextStyle(color: AppColors.textSecondary)),
        // Дети строятся только когда плитка раскрыта — значит, запрос
        // треков уйдёт только по тапу на альбом.
        children: [
          FutureBuilder<List<Track>>(
            future: _albumTracks.putIfAbsent(
                album.id, () => widget.source.loadAlbumTracks(album)),
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              final tracks = snap.data ?? const <Track>[];
              if (tracks.isEmpty) {
                return TextButton(
                  onPressed: () => setState(() => _albumTracks.remove(album.id)),
                  child: Text(context.l10n.retry),
                );
              }
              return Column(children: [for (final t in tracks) tile(t, tracks)]);
            },
          ),
        ],
      ),
    );
  }
}
